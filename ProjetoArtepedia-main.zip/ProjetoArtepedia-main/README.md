# ProjetoArtepedia

#Descrição:
Iremos desenvolver uma espécie de enciclopédia de artistas, com alguns elementos 
inspirados no Spotify. No projeto, cada colaborador escolherá um artista de sua preferência. 
Haverá uma página principal que redirecionará para a página do artista escolhido ao clicar no 
respectivo link. A página de cada artista apresentará uma biografia, as músicas mais ouvidas, 
os álbuns mais vendidos, artistas de gêneros musicais semelhantes e os links para as redes 
sociais do artista.

#Integrantes
°Ana Beatriz da Silva Linhares;
°Daniel De Lima Costa dos Santos;
°Jose Gustavo Martinho Araújo de Almeida;
°Richard Gonçalves Pereira;
°Rafael Lucas dos Santos Duarte.
